BuckStar_IF54E
==============
##Projeto de software para a matéria de Oficina de Integração do 4º Semestre do curso de Análise e Desenvolvimento de Sistemas.##

Esse projeto visa o desenvolvimento de um *software WEB* destinado ao setor de **compras de um minimercado**

##documentação##
Essa seção contém todos os arquivos referentes a documentação do projeto

##implementação##
Essa seção contém todos os arquivos de código fonte, do projeto