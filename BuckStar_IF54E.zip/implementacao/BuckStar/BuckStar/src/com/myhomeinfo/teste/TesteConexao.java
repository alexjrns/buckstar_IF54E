package com.myhomeinfo.teste;

import com.myhomeinfo.jdbc.Conexao;

public class TesteConexao {

	public static void main(String[] args) {
		Conexao.getConnection();
	}

}
